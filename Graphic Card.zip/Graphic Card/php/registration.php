<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm = $_POST['confirm_password']; 
    
    $servername = "localhost";
    $db_username = "root"; 
    $db_password = ""; 
    $database = "graphic"; 

    $conn = mysqli_connect($servername, $db_username, $db_password, $database);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "INSERT INTO `registration` (`username`, `email`, `password`, `confirm`) VALUES ('$username', '$email', '$password', '$confirm')";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        echo "<script>alert('Registration Successful!! Please Login to Proceed.'); window.location.href = 'http://localhost/project/Graphic%20Card/login.html';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
