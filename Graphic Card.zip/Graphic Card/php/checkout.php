<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
    $name = $_POST['name'];
    $card_number = $_POST['card_number'];
    $card_type = $_POST['card_type'];
    $exp_date = $_POST['exp_date'];
    $cvv = $_POST['cvv'];


    if (empty($name) || empty($card_number) || empty($card_type) || empty($exp_date) || empty($cvv)) {
        echo "All fields are required.";
    } else {
      
        $servername = "localhost"; 
        $username = "root";
        $password = "";
        $dbname = "graphic";

        $conn = mysqli_connect($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $sql = "INSERT INTO checkout (name, card_number, card_type, exp_date, cvv) VALUES ('$name', '$card_number', '$card_type', '$exp_date', '$cvv')";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Payment Successful!'); window.location.href = 'http://localhost/project/Graphic%20Card/index.html';</script>";
        } else {
            echo "Error: " . $conn->error;
        }

        $conn->close();
    }
} else {
   
    header("Location: checkout.html");
    exit();
}
?>
