<?php

$servername = "localhost";
$username = "root";
$password = ""; 
$database = "graphic"; 


$conn = new mysqli($servername, $username, $password, $database);


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";


$email = $_POST['email'];


$sql = "INSERT INTO `subscriber` (`email`) VALUES ('$email');";
if ($conn->query($sql) === TRUE) {
    echo "<script>alert('Thanks For Subscribing'); window.location.href = 'http://localhost/project/Graphic%20Card/index.html';</script>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}


$conn->close();
?>
