<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    $Your_Name = $_POST['Your_Name'];
    $Phone_Number = $_POST['Phone_Number'];
    $Email = $_POST['Email'];
    $Message = $_POST['Message'];

    $servername = "localhost";
    $db_username = "root";
    $db_password = ""; 
    $database = "graphic";

    $conn = mysqli_connect($servername, $db_username, $db_password, $database);


    if (!$conn) {
        die("Sorry we failed to connect: " . mysqli_connect_error());
    } else {

        $stmt = $conn->prepare("INSERT INTO `contact` (`Name`, `Phone number`, `Email`, `Address`) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $Your_Name, $Phone_Number, $Email, $Message);
        
        if ($stmt->execute()) {
            echo "<script>alert('Thanks For Sharing Your Contact With Us'); window.location.href = 'http://localhost/project/Graphic%20Card/contact.html';</script>";
        } else {
            echo "Error: " . $stmt->error;
        }
        
        $stmt->close();
        $conn->close();
    }
}
?>
