<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['productName']; 
    $price = $_POST['price']; 

    $servername = "localhost";
    $username = "root"; 
    $password = ""; 
    $dbname = "graphic"; 

    $conn = mysqli_connect($servername, $username, $password, $dbname);

    if (!$conn) {
        die("Sorry we failed to connect: " . mysqli_connect_error());
    } else {
        $sql = "INSERT INTO cart (Productname, Price) VALUES ('$name', '$price')";
        $result = mysqli_query($conn, $sql);

        if ($result) {
            echo "<script>alert('Product added to cart successfully'); window.location.href = 'http://localhost/project/Graphic%20Card/product.html';</script>";
           
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }

    $conn->close();
}
?>
