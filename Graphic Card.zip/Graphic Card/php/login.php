<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    $username = $_POST['username'];
    $password = $_POST['password'];

    $servername = "localhost";
    $db_username = "root"; 
    $db_password = ""; 
    $database = "graphic";

    $conn = mysqli_connect($servername, $db_username, $db_password, $database);

    if (!$conn) {
        die("Sorry we failed to connect: " . mysqli_connect_error());
    } else {
        
        $check_query = "SELECT * FROM registration WHERE username='$username'";
        $result = mysqli_query($conn, $check_query);

        if (mysqli_num_rows($result) == 1) {
           
            $row = mysqli_fetch_assoc($result);
            if ($password === $row['password']) {
                
                echo "<script>alert('Login Successful!!'); window.location.href = 'http://localhost/project/Graphic%20Card/index.html';</script>";
            } else {
                
                echo "<script>alert('Incorrect password. Please try again.'); window.location.href = 'http://localhost/project/Graphic%20Card/login.html'</script>";
            }
        } else {
    
            echo "<script>alert('User does not exist. Please check your entry or register.'); window.location.href = 'http://localhost/project/Graphic%20Card/login.html';</script>";
        }
    }
}
?>
