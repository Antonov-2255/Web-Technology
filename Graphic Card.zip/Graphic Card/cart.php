<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="css/cart.css">
   
</head>
<body>

<h2>Shopping Cart</h2>

<table>
    <thead>
        <tr>
            <th>Graphic Card</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Total</th>
            <th>Remove Item</th>
        </tr>
    </thead>
    <tbody>
        <?php
       
        $servername = "localhost";
        $username = "root"; 
        $password = ""; 
        $database = "graphic"; 

        $conn = new mysqli($servername, $username, $password, $database);


        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

       // this is for remove item from database
        if(isset($_POST['product_name'])) {
            $productName = $_POST['product_name'];

            
            $sql = "DELETE FROM cart WHERE Productname = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $productName);

            
            if ($stmt->execute()) {
                
                header("Location: ".$_SERVER['PHP_SELF']);
                exit();
            } else {
                echo "<script>alert('Error removing item: " . $conn->error . "');</script>";
            }

            $stmt->close();
        }

        // this is for Retrieve items from the database
        $sql = "SELECT Productname, price FROM cart";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
     
            while($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<tr class='cart-item'>";
                echo "<td>" . $row["Productname"]. "</td>";
                echo "<td>₹" . $row["price"]. "</td>";
                echo "<td><input type='number' class='quantity-input' value='1'></td>";
                echo "<td class='total-amount'>₹" . $row["price"]. "</td>";
                echo "<td>";
                echo "<form action='' method='POST'>";
                echo "<input type='hidden' name='product_name' value='" . $row["Productname"] . "'>";
                echo "<button type='submit'>Remove</button>";
                echo "</form>";
                echo "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='5' style='text-align: center;'>No items in the cart</td></tr>";

        }

        $conn->close();
        ?>
    </tbody>
</table>

<button onclick="checkout()" class="checkout-button">Checkout</button>
<button onclick="back()" class="checkout-button">GO Back</button>


<script>  // this is for the quantity function
    document.addEventListener("DOMContentLoaded", function() {
       
        var quantityInputs = document.querySelectorAll('.quantity-input');

        
        quantityInputs.forEach(function(input) {
            input.addEventListener('input', function() {
                var quantity = parseInt(this.value);
                var price = parseInt(this.parentElement.previousElementSibling.innerText.replace('₹', ''));
                var totalAmountElement = this.parentElement.nextElementSibling;
                
               
                if (quantity < 0) {
                    quantity = 0;
                    this.value = quantity;
                }
                
                var total = quantity * price;
                totalAmountElement.innerText = '₹' + total;
            });
        });
    });

    function checkout() {
    var cartItems = document.querySelectorAll('.cart-item');
    
    if (cartItems.length === 0) {
        alert('Cart is empty');
    } else {
        window.location.href = "checkout.html";
    }
}


    function back() {
    window.location.href = "product.html";
    }

</script>


</body>
</html>
